package maze

case object Update
case class GameState(state: String)


